import React, { useState } from 'react';

export default function ProteinDetector() {
  const [image, setImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState([]);

  const handleImageChange = (e) => {
    setImage(e.target.files[0]);
    setResults([]);
  };

  const handleAnalyze = async () => {
    if (!image) return;
    setLoading(true);

    const detectedFoods = ['Chicken Breast', 'White Rice', 'Broccoli'];
    const foodData = {
      'Chicken Breast': { grams: 150, protein: 46 },
      'White Rice': { grams: 100, protein: 2.5 },
      'Broccoli': { grams: 50, protein: 1.3 },
    };

    const displayData = detectedFoods.map((food) => {
      const data = foodData[food];
      return {
        food,
        grams: data.grams,
        protein: data.protein,
      };
    });

    setResults(displayData);
    setLoading(false);
  };

  return (
    <div style={{ padding: 20, maxWidth: 400, margin: 'auto' }}>
      <h1>Protein From Picture 🍽️</h1>
      <input type="file" accept="image/*" onChange={handleImageChange} />
      <button onClick={handleAnalyze} disabled={loading}>
        {loading ? 'Analyzing...' : 'Analyze Protein'}
      </button>

      {results.length > 0 && (
        <ul style={{ marginTop: 20 }}>
          {results.map((item, idx) => (
            <li key={idx}>
              {item.food} ({item.grams}g): <strong>{item.protein}g protein</strong>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}